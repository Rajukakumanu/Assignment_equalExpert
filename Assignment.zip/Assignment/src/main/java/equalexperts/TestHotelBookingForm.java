package equalexperts;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestHotelBookingForm {

    public static WebDriver driver;

    @BeforeMethod
    public static void beforeTestMethod() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",
                "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.navigate().to("http://hotel-test.equalexperts.io/");
        Thread.sleep(2000);

    }

    @AfterMethod
    public static void afterTestMethod() {
        driver.close();
        driver.quit();
    }

    @Test
    public static void saveRecordInTheForm() throws InterruptedException {
        String firstName ="RajuTest"+getRandomNumberInRange(1,1000);
        boolean bln = false;
        driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys(firstName);
        driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Kakumanu");
        driver.findElement(By.xpath("//input[@id='totalprice']")).sendKeys("100");
        Select select = new Select(driver.findElement(By.id("depositpaid")));
        select.selectByVisibleText("false");
        driver.findElement(By.xpath("//input[@id='checkin']")).sendKeys("2022-03-15");
        driver.findElement(By.xpath("//input[@id='checkout']")).sendKeys("2022-03-17");
        driver.findElement(By.xpath("//*[contains(@value,' Save ')]")).click();
        Thread.sleep(5000);
        List<WebElement> elements = driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[2]/div"));
        for (int index = 2; index <= elements.size(); index++) {
            List<WebElement> firstnamelem = driver
                    .findElements(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[" + index + "]/div/p"));
            if (firstnamelem.get(0).getText().trim().equalsIgnoreCase(firstName)) {
                bln = true;
                break;
            }
        }
        Assert.assertEquals(bln,true);
    }

    @Test
    public static void deleteRecordFromTheForm() throws InterruptedException {
        String firtName = "RajuTest"+getRandomNumberInRange(1001,2000);
        driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys(firtName);
        driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Kakumanu");
        driver.findElement(By.xpath("//input[@id='totalprice']")).sendKeys("100");
        Select select = new Select(driver.findElement(By.id("depositpaid")));
        select.selectByVisibleText("false");
        driver.findElement(By.xpath("//input[@id='checkin']")).sendKeys("2022-03-15");
        driver.findElement(By.xpath("//input[@id='checkout']")).sendKeys("2022-03-17");
        driver.findElement(By.xpath("//*[contains(@value,' Save ')]")).click();
        Thread.sleep(5000);
        List<WebElement> elements = driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[2]/div"));
        int afterAddtionSize=elements.size();
        int afterDeletionSize = 0;
        for (int index = 2; index <= elements.size(); index++) {
            List<WebElement> firstnamelem = driver
                    .findElements(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[" + index + "]/div/p"));
            System.out.println(firstnamelem.get(0).getText());
            if (firstnamelem.get(0).getText().trim().equalsIgnoreCase(firtName)) {
                System.out.println("/html[1]/body[1]/div[1]/div[2]/div[" + index + "]/div/input");
                WebElement eleme = driver
                        .findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[" + index + "]/div/input"));
                eleme.click();
                break;
            }
        }
    }
    private static int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}